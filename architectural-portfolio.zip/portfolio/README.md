# Architectural Portfolio Website Template

A plain HTML, CSS, and JavaScript website. No installation, no backend, no paid service. It works when you double-click `index.html` and when published on GitHub Pages.

All sample projects, text, and images are **placeholders**. Replace them with your own work before sharing the site.

## What is in the folder

```
index.html            Home page
projects.html         Selected Works (project gallery)
project.html          Reusable project detail page (do not edit; it reads your data file)
about.html            About page
resume.html           Resume page
contact.html          Contact page
js/projects-data.js   YOUR PROJECTS: edit this to add or change projects
js/main.js            Site behavior (menu and project pages). Usually no edits needed.
css/style.css         Colors, fonts, and layout
assets/images/        All images
assets/documents/     Your resume PDF
.nojekyll             Tells GitHub Pages to publish the files as they are. Keep it.
```

## 1. Edit your name and introduction

Search for `[YOUR FULL NAME]` and replace it everywhere. It appears in every `.html` file (header, footer, page title). In GitHub, open each file, click the pencil icon, and use the browser search (Ctrl+F) to find it.

Your introduction is in `index.html`. Look for the comment `EDIT: name, title, and introduction`. Change the text between the tags, and leave the tags themselves (`<p>`, `</p>`) alone.

## 2. Replace project images and drawings

1. Prepare your images (see "Image tips" below).
2. Upload them to `assets/images/` in GitHub (Add file, Upload files).
3. Open `js/projects-data.js` and change the path, for example:
   `cover: "assets/images/my-house-cover.jpg"`

File names are case sensitive on GitHub. `House.JPG` and `house.jpg` are different files. Use lowercase letters, numbers, and hyphens only. No spaces.

Drawings (plans, elevations, sections) are shown on a white frame without cropping. Renderings are cropped slightly to fit wide layouts, so keep important details away from the edges.

**Image tips**
- Use JPG or WebP for renderings and photos. Use PNG for line drawings with text.
- Aim for 1600 to 2400 pixels wide and under 600 KB per image. The free tool squoosh.app can shrink files.
- Every image in `projects-data.js` has an `alt` line. Describe what the image shows in one short sentence. Screen readers and search engines use it.

## 3. Add, remove, or edit projects

All projects are in `js/projects-data.js`. Each project is one block that starts with `{` and ends with `}`.

**Add a project**
1. Copy a full block, from `{` to `}`.
2. Paste it after the last block. Put a comma after the previous block's closing `}`.
3. Change `id` to something new, such as `"project-5"`.
4. Replace the text and image paths.

**Remove a project:** delete its whole block. Make sure no comma is left after the last block.

**Remove the "Sample" tag:** delete the line `sample: true,` in your block.

**Choose the home page project:** keep `featured: true,` in only one block.

**Categories:** write any category you like, for example Architectural Design, Residential Architecture, Institutional Architecture, Interior Design, Master Planning, 3D Visualization.

**Hide a section on the project page:** leave its list empty, for example `process: []`.

If a project page goes blank, you almost always have a missing comma, quote mark, or bracket in this file. See troubleshooting.

## 4. Update your resume and contact information

**Resume PDF:** upload your PDF to `assets/documents/` and name it exactly `resume.pdf`. Replace the old file (delete the placeholder, then upload yours). The download buttons will work without any other change.

**Resume page text:** edit `resume.html`. Repeat the `<li>...</li>` row to add more entries.

**Profile photo:** upload `profile.jpg` to `assets/images/`, then in `about.html` change `assets/images/profile.svg` to `assets/images/profile.jpg`. Update the `alt` text to describe the photo.

**Contact details:** search for these placeholders in `contact.html`, and the footer of every page:
- `your.email@example.com`
- `https://www.linkedin.com/in/your-profile`
- Behance and Instagram links. Delete rows you do not use.

There is no contact form on purpose. A form needs a paid or external service to work, and a fake form would lose you messages.

## 5. Customize colors and fonts

Open `css/style.css`. The top block (`:root`) holds every color and font.

- `--ivory` is the main background and `--charcoal` is the text color.
- `--text-muted` is a darker taupe used for small secondary text. The original taupe is too light to read at small sizes.
- Fonts are Cormorant Garamond (headings) and Hanken Grotesk (body), loaded from Google Fonts. To change them, pick new fonts at fonts.google.com, replace the `<link href="https://fonts.googleapis.com/...">` line in each HTML file, and update `--font-heading` and `--font-body`.
- If a visitor is offline, the site falls back to Georgia and Arial. It still looks clean.

## 6. Upload the website to GitHub

1. Create a free account at github.com.
2. Click **New repository**. Give it a name such as `portfolio`. Choose **Public**. Click **Create repository**.
3. Click **uploading an existing file**.
4. Unzip this template on your computer. Open the unzipped folder and drag **everything inside it** (the files and folders, not the outer folder) into the GitHub upload area. Folders upload with their contents.
5. Note that the `.nojekyll` file may be hidden on your computer. If it did not upload, click **Add file, Create new file**, type `.nojekyll` as the name, and commit it.
6. Click **Commit changes**.

## 7. Turn on GitHub Pages

1. In your repository, open **Settings**, then **Pages** in the left menu.
2. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
3. Set **Branch** to `main` and the folder to `/ (root)`. Click **Save**.
4. Wait one to two minutes, then refresh. Your site address appears at the top:
   `https://YOUR-USERNAME.github.io/portfolio/`

Every time you commit a change, the site updates within a couple of minutes. All links in this template are relative, so it works in a repository subfolder like `/portfolio/`.

Tip: name the repository `YOUR-USERNAME.github.io` if you want a shorter address without the repository name.

## 8. Troubleshooting

| Problem | Likely cause and fix |
|---|---|
| Site shows 404 | Pages is not on yet, or `index.html` is inside a subfolder. It must be at the top level of the repository. Wait two minutes after saving. |
| Page has no styling | The `css` folder did not upload, or the folder name changed. Check that `css/style.css` exists. |
| An image is missing | Check spelling and capital letters in the path. GitHub is case sensitive. Check that the file is in `assets/images/`. |
| Project gallery is empty or a project page is blank | There is a typo in `js/projects-data.js`. Look for a missing comma between blocks, a missing quote mark, or a leftover comma after the last item in a list. |
| "Project not found" | The `id` in the link does not match any `id` in the data file. |
| My change does not show | Wait a couple of minutes, then hard refresh (Ctrl+Shift+R, or Cmd+Shift+R on Mac). |
| Resume download shows the placeholder | You uploaded a file with a different name. It must be `assets/documents/resume.pdf`. |
| Fonts look different | Google Fonts did not load (offline or blocked). The fallback fonts are used. |

## Final checklist before sending the link to employers

- [ ] `[YOUR FULL NAME]` is gone from every page (search each file)
- [ ] Introduction, About, and Resume text are written in your own words
- [ ] Every sample project is replaced or deleted, and "Sample" tags are gone
- [ ] No "Replace this" or "20XX" text remains (search `projects-data.js`)
- [ ] Only real education, experience, and software are listed
- [ ] `resume.pdf` is your real resume
- [ ] Email and LinkedIn links open the right place (click each one on the live site)
- [ ] Every project card opens its page, and the Previous and Next links work
- [ ] Every image loads and has a useful `alt` description
- [ ] Menu works on your phone (tap Menu, then each link)
- [ ] Site looks right on phone, tablet, and desktop
- [ ] You can reach every link using only the Tab key, and the focus outline is visible
- [ ] Live address `https://YOUR-USERNAME.github.io/REPO-NAME/` opens in a private browser window
