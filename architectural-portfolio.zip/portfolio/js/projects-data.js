/* ==========================================================
   YOUR PROJECTS LIVE HERE.
   Every project is one block between { and }. To add a project,
   copy a whole block, paste it below the last one (keep a comma
   between blocks), then change the text and image paths.
   Projects marked sample: true show a "Sample" tag. Delete that
   line once the project is yours.
   Image files go in assets/images/ (see README).
   ========================================================== */
window.PROJECTS = [

  {
    id: "project-1",                     // unique, lowercase, no spaces
    sample: true,
    featured: true,                      // shows on the home page (use for one project)
    title: "Sample Project One",
    category: "Residential Architecture",
    location: "City, Country",
    year: "20XX",
    status: "Academic project",          // e.g. Academic project, Built, Competition entry
    type: "Single-family house",
    cover: "assets/images/project-1-cover.svg",
    coverAlt: "Placeholder rendering of a residential building",
    overview: "Replace this with two or three sentences that explain what the project is and what you were asked to design.",
    concept: "Replace this with your design concept: the main idea behind the building and how it responds to the site, climate, and users.",
    objectives: [
      "Replace with your first design objective",
      "Replace with your second design objective",
      "Replace with your third design objective"
    ],
    site: "Replace this with your site analysis: context, climate, access, views, and constraints.",
    features: [
      "Replace with a key design feature",
      "Replace with another key design feature"
    ],
    drawings: [
      { src: "assets/images/placeholder-plan.svg", alt: "Placeholder floor plan drawing", caption: "Ground floor plan" },
      { src: "assets/images/placeholder-elevation.svg", alt: "Placeholder elevation drawing", caption: "South elevation" }
    ],
    renders: [
      { src: "assets/images/placeholder-render.svg", alt: "Placeholder 3D rendering", caption: "Exterior view" },
      { src: "assets/images/project-1-cover.svg", alt: "Placeholder interior rendering", caption: "Interior view" },
      { src: "assets/images/project-2-cover.svg", alt: "Placeholder detail rendering", caption: "Detail view" }
    ],
    process: [
      { src: "assets/images/placeholder-diagram.svg", alt: "Placeholder concept diagram", caption: "Concept diagram" },
      { src: "assets/images/placeholder-diagram.svg", alt: "Placeholder massing study", caption: "Massing study" },
      { src: "assets/images/placeholder-diagram.svg", alt: "Placeholder sketch", caption: "Design sketch" }
    ]
  },

  {
    id: "project-2",
    sample: true,
    title: "Sample Project Two",
    category: "Institutional Architecture",
    location: "City, Country",
    year: "20XX",
    status: "Academic project",
    type: "Community library",
    cover: "assets/images/project-2-cover.svg",
    coverAlt: "Placeholder rendering of an institutional building",
    overview: "Replace this with a short overview of the project.",
    concept: "Replace this with your design concept.",
    objectives: ["Replace with objective one", "Replace with objective two"],
    site: "Replace this with your site analysis.",
    features: ["Replace with a key feature"],
    drawings: [
      { src: "assets/images/placeholder-plan.svg", alt: "Placeholder floor plan drawing", caption: "Floor plan" },
      { src: "assets/images/placeholder-elevation.svg", alt: "Placeholder elevation drawing", caption: "Elevation" }
    ],
    renders: [
      { src: "assets/images/placeholder-render.svg", alt: "Placeholder 3D rendering", caption: "Exterior view" }
    ],
    process: []
  },

  {
    id: "project-3",
    sample: true,
    title: "Sample Project Three",
    category: "Interior Design",
    location: "City, Country",
    year: "20XX",
    status: "Academic project",
    type: "Cafe interior",
    cover: "assets/images/project-3-cover.svg",
    coverAlt: "Placeholder rendering of an interior space",
    overview: "Replace this with a short overview of the project.",
    concept: "Replace this with your design concept.",
    objectives: ["Replace with objective one", "Replace with objective two"],
    site: "Replace this with your site analysis.",
    features: ["Replace with a key feature"],
    drawings: [
      { src: "assets/images/placeholder-plan.svg", alt: "Placeholder interior plan", caption: "Interior plan" }
    ],
    renders: [
      { src: "assets/images/placeholder-render.svg", alt: "Placeholder interior rendering", caption: "Interior view" }
    ],
    process: []
  },

  {
    id: "project-4",
    sample: true,
    title: "Sample Project Four",
    category: "Master Planning",
    location: "City, Country",
    year: "20XX",
    status: "Academic project",
    type: "Mixed-use community",
    cover: "assets/images/project-4-cover.svg",
    coverAlt: "Placeholder master plan illustration",
    overview: "Replace this with a short overview of the project.",
    concept: "Replace this with your design concept.",
    objectives: ["Replace with objective one", "Replace with objective two"],
    site: "Replace this with your site analysis.",
    features: ["Replace with a key feature"],
    drawings: [
      { src: "assets/images/placeholder-plan.svg", alt: "Placeholder site plan", caption: "Site plan" }
    ],
    renders: [
      { src: "assets/images/placeholder-render.svg", alt: "Placeholder aerial rendering", caption: "Aerial view" }
    ],
    process: []
  }

  /* To add a project: put a comma after the closing brace above, then paste a new block here. */
];
