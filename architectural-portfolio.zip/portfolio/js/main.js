/* Site scripts: mobile menu, footer year, and project pages built from js/projects-data.js */
(function () {
  var P = window.PROJECTS || [];
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function $(id) { return document.getElementById(id); }

  // Mobile menu
  var btn = $("menu-btn"), nav = $("nav");
  if (btn && nav) {
    btn.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      btn.setAttribute("aria-expanded", open ? "true" : "false");
      btn.textContent = open ? "Close" : "Menu";
    });
  }
  var yr = $("year"); if (yr) yr.textContent = new Date().getFullYear();

  function link(id) { return "project.html?id=" + encodeURIComponent(id); }

  function card(p) {
    return '<a class="card" href="' + link(p.id) + '">' +
      '<div class="thumb"><img src="' + esc(p.cover) + '" alt="' + esc(p.coverAlt) + '" loading="lazy">' +
      (p.sample ? '<span class="tag">Sample</span>' : '') + '</div>' +
      '<h3>' + esc(p.title) + '</h3>' +
      '<p class="meta">' + esc(p.category) + '</p>' +
      '<p class="meta">' + esc(p.location) + ', ' + esc(p.year) + '</p></a>';
  }

  // Project grid (projects.html)
  var grid = $("project-grid");
  if (grid) grid.innerHTML = P.map(card).join("");

  // Featured project (index.html)
  var feat = $("featured");
  if (feat) {
    var f = P.filter(function (p) { return p.featured; })[0] || P[0];
    if (f) {
      feat.innerHTML = '<a href="' + link(f.id) + '"><img src="' + esc(f.cover) + '" alt="' + esc(f.coverAlt) + '"></a>' +
        '<figcaption><span>' + esc(f.title) + (f.sample ? ' (sample)' : '') + '</span><span>' + esc(f.category) + ', ' + esc(f.year) + '</span></figcaption>';
    }
  }

  // Project detail (project.html?id=project-1)
  var box = $("project-detail");
  if (!box) return;
  var id = new URLSearchParams(location.search).get("id");
  var i = P.map(function (p) { return p.id; }).indexOf(id);
  if (i < 0) {
    box.innerHTML = '<div class="container section"><h1>Project not found</h1><p>Check the link, or return to <a href="projects.html">Selected Works</a>.</p></div>';
    return;
  }
  var p = P[i];
  document.title = p.title + " | Portfolio";

  function figs(items, kind) {
    return (items || []).map(function (x) {
      return '<figure' + (kind ? ' class="' + kind + '"' : '') + '><img src="' + esc(x.src) + '" alt="' + esc(x.alt) + '" loading="lazy">' +
        (x.caption ? '<figcaption>' + esc(x.caption) + '</figcaption>' : '') + '</figure>';
    }).join("");
  }
  function list(a) {
    return a && a.length ? "<ul>" + a.map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("") + "</ul>" : "";
  }
  function row(title, body, alt) {
    return '<section class="section' + (alt ? ' alt' : '') + '"><div class="container split"><h2>' + title + '</h2><div>' + body + '</div></div></section>';
  }
  var r = p.renders || [];
  var html =
    '<header class="page-head"><div class="container"><h1>' + esc(p.title) + '</h1><p>' + esc(p.overview) + '</p>' +
    (p.sample ? '<p class="notice">This is a sample project with placeholder content. Replace it with your own work.</p>' : '') +
    '<dl class="facts"><div><dt>Type</dt><dd>' + esc(p.type) + '</dd></div><div><dt>Location</dt><dd>' + esc(p.location) + '</dd></div>' +
    '<div><dt>Year</dt><dd>' + esc(p.year) + '</dd></div><div><dt>Status</dt><dd>' + esc(p.status) + '</dd></div></dl></div>' +
    '<figure class="full container"><img src="' + esc(p.cover) + '" alt="' + esc(p.coverAlt) + '"></figure></header>' +
    row("Design concept", "<p>" + esc(p.concept) + "</p>") +
    row("Design objectives", list(p.objectives), true) +
    row("Site analysis", "<p>" + esc(p.site) + "</p>") +
    (p.drawings && p.drawings.length ? '<section class="section alt"><div class="container"><h2>Plans, elevations, and sections</h2><div class="gallery two">' + figs(p.drawings, "drawing") + '</div></div></section>' : "") +
    (r.length ? '<section class="section"><div class="container"><h2>Visualizations</h2><div class="gallery">' + figs(r.slice(0, 1)) + '</div>' +
      (r.length > 1 ? '<div class="gallery two">' + figs(r.slice(1)) + '</div>' : '') + '</div></section>' : "") +
    (p.process && p.process.length ? '<section class="section alt"><div class="container"><h2>Design development</h2><div class="gallery three">' + figs(p.process) + '</div></div></section>' : "") +
    (p.features && p.features.length ? row("Key design features", list(p.features)) : "");

  var prev = P[i - 1], next = P[i + 1];
  html += '<nav class="container section" aria-label="Project navigation"><div class="pager"><span>' +
    (prev ? '<a href="' + link(prev.id) + '">Previous: ' + esc(prev.title) + '</a>' : '') + '</span><a href="projects.html">All projects</a><span>' +
    (next ? '<a href="' + link(next.id) + '">Next: ' + esc(next.title) + '</a>' : '') + '</span></div></nav>';
  box.innerHTML = html;
})();
